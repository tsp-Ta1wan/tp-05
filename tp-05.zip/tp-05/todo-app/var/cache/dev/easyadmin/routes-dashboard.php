<?php return array (
  'app_admin_dashboard_index' => 'App\\Controller\\Admin\\DashboardController::index',
);