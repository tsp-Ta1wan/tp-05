<?php

namespace App\Controller;

use App\Repository\TagRepository;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class TagController extends AbstractController
{
    #[Route('/tag', name: 'app_tag')]
    public function index(): Response
    {
        dump("Hello world");
        return $this->render('tag/index.html.twig', [
            'controller_name' => 'TagController',
        ]);
    }
    /**
     * Lists all tags entities.
     */
    #[Route('/tag/list', name: 'tag_list', methods: ['GET'])]
    public function listAction(TagRepository $tagRepository)
    {
        $htmlpage = '<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>todos list!</title>
    </head>
    <body>
        <h1>tags list</h1>
        <p>Here are all your tags:</p>
        <ul>';
        
        $tags = $tagRepository->findAll();
        foreach($tags as $tag) {
            $htmlpage .= '<li>'. $tag->getTag() .'</li>';
        }
        $htmlpage .= '</ul>';
        
        $htmlpage .= '</body></html>';
        
        return new Response(
            $htmlpage,
            Response::HTTP_OK,
            array('content-type' => 'text/html')
            );
    }
}
