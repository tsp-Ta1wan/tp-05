<?php

namespace App\Entity;

use App\Repository\TagRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: TagRepository::class)]
class Tag
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $Tag = null;

    /**
     * @var Collection<int, Todo>
     */
    #[ORM\ManyToMany(targetEntity: Todo::class, mappedBy: 'tags')]
    private Collection $todos;

    public function __construct()
    {
        $this->todos = new ArrayCollection();
    }
    
    public function __toString()
    {
        $s = '';
        $s .= $this->getId() .' '. $this->getTag() .' ';
 
        return $s;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTag(): ?string
    {
        return $this->Tag;
    }

    public function setTag(string $Tag): static
    {
        $this->Tag = $Tag;

        return $this;
    }

    /**
     * @return Collection<int, Todo>
     */
    public function getTodos(): Collection
    {
        return $this->todos;
    }

    public function addTodo(Todo $todo): static
    {
        if (!$this->todos->contains($todo)) {
            $this->todos->add($todo);
            $todo->addTag($this);
        }

        return $this;
    }

    public function removeTodo(Todo $todo): static
    {
        if ($this->todos->removeElement($todo)) {
            $todo->removeTag($this);
        }

        return $this;
    }
}
